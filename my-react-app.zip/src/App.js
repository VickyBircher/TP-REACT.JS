import logo from './logo.svg';
import './App.css';
import Formularios from "./components/Formularios.js"

function App() {
  return (
    <div className="App">
<div className='container'>
  <div className='row'>
  
  <div className='col-md-6'>
    <div className='align-items-center'>
      <Formularios/>
    </div>

    </div>
    <div className='col-md-6'>
    </div>
    </div>
  </div>
</div>  
  );
}

export default App;
