import logo from './logo.svg';
import './App.css';
import Formularios from "./components/Formularios.js"
import Lista from './components/Lista';
import { useState } from 'react';

// const [mascota, setMascota] = useState();
// const [dueño, setDueño] = useState();
// const [horario, setHoriario] = useState();
// const [sintomas, setSintomas] = useState();


function App() {

  return (
    <div className="App">
      <h1 style={{color:"#fff"}}> Veterinaria Bircher</h1>

<div className='container'>
  <div className='row'>
  
   <div className='col-md-6'>
      <h3 style={{color: "#fff"}}>Crear mi cita</h3>
      <Formularios/>

    </div>
    <div className='col-md-6'>
      <br/>
      <div  className='text-center' >
      <h3 style={{color: "#fff"}}> Administrador </h3>
      <Lista/>
      <button className="btn btn-primary"> Pedir turno</button>
      </div>
    </div>
    </div>
  </div>
</div>  
  );
}

export default App;
