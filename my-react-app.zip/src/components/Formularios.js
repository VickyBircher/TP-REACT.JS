import React from "react";
import Form from "./Form.js";
import '../App.css';

function Formularios() {
    return (
     <>
     <Form placeHolder="Nombre mascota"/>
     <Form placeHolder="Nombre dueño de mascota"/>
     <Form placeHolder="Fecha"/>
     <Form placeHolder="Síntomas"/> 
     </>
    );
  }
  
  export default Formularios;
