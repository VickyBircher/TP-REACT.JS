import React from "react";
import Form from "./Form.js";
import '../App.css';

function Formularios() {
    return (
     <>
     <Form tipo="text" placeHolder="Nombre mascota"/>
     <Form tipo="text" placeHolder="Nombre dueño de mascota"/>
     <Form tipo="date" placeHolder="Fecha"/>
     <Form tipo="time" placeHolder="Horario"/>
     <Form tipo="text" placeHolder="Síntomas"/> 
     </>
    );
  }
  
  export default Formularios;
