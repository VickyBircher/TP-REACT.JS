import React from "react";
import '../App.css';
import Boton from "./Boton";
function Lista(props) {
    return (
     <>
     <div className="lista column">
         <p><strong>Mascota:</strong></p>
         <p><strong>Dueño:</strong></p>
         <p><strong>Fecha:</strong></p>
         <p><strong>Síntomas:</strong></p>
          <Boton/>

     </div>
     </>
    );
  }
  
  export default Lista;