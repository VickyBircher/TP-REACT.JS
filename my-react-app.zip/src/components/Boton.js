import React from "react";
import '../App.css';

function Boton(props) {
    return (
     <>
     <button className="btn btn-primary buton"> Eliminar <strong>×</strong></button>
     </>
    );
  }
  
  export default Boton;