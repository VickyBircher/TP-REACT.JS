import React from "react";
import '../App.css';

function Form(props) {
    return (
     <>
      <input type="text" name="name" placeholder={props.placeHolder}/>
     </>
    );
  }
  
  export default Form;