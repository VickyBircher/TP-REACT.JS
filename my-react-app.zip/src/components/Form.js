import React from "react";
import '../App.css';

function Form(props) {
    return (
    <>
      <input className="formm" type={props.tipo} name="name" placeholder={props.placeHolder}/>

     </>
    );
  }
  
  export default Form;